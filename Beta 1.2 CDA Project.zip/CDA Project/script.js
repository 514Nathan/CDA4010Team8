


const tabs = document.querySelectorAll('[data-tab-target]');
const tabContents = document.querySelectorAll('[data-tab-content]');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const target = document.querySelector(tab.dataset.tabTarget);
    tabContents.forEach(tabContent => {
      tabContent.classList.remove('active');
    })
    tabs.forEach(tab => {
      tab.classList.remove('active');
    })
    tab.classList.add('active');
    target.classList.add('active');
  })
})

function CriminalY(){
		document.getElementById('test').style.display = "block";
	
}
function CriminalN(){
		document.getElementById('test').style.display = "none";
	
}

function MilitaryY(){
		document.getElementById('military').style.display = "block";
		
		document.getElementById('airforce').required = true;
}
function MilitaryN(){
	
		document.getElementById('military').style.display = "none";
		
		document.getElementById('airforce').required = false;
	
}


function DLY(){
		document.getElementById('DL').style.display = "block";
		
		document.getElementById('license').required = true;
			document.getElementById('licenseexp').required = true;
}
function DLN(){
		document.getElementById('DL').style.display = "none";
		
		document.getElementById('airforce').required = false;
	
}

function vehicleY(){
		document.getElementById('vehicle').style.display = "block";
	
}
function vehicleN(){
		document.getElementById('vehicle').style.display = "none";
	
}

Crime = 0;
function addCrim(){
	crim = document.getElementById("Crim");
	

	add1 = document.createTextNode("Crime Date: ");
	
	add2 = document.createElement("input");
	add2.setAttribute("type","date");
	add2.setAttribute("id","DateCrime" +(++Crime));
	add2.setAttribute("required", "");
	add2.setAttribute("max","2025-12-31");
	add2.setAttribute("min","1955-01-01"); 
	add3 = document.createElement("p");



	add4 = document.createTextNode("What kind of crime was it?");
	
	
	add5 = document.createElement("input");
	add5.setAttribute("type","radio");
	add5.setAttribute("id","misdemeanor" +(Crime));
	add5.setAttribute("name","type-crime" +(Crime));
	add5.setAttribute("required", "");
	
	add7 = document.createTextNode("Misdemeanor");
	
	
	
	add8 = document.createElement("input");
	add8.setAttribute("type","radio");
	add8.setAttribute("id","felony" +(Crime));
	add8.setAttribute("name","type-crime" +(Crime));
	add8.setAttribute("required", "");


	add9 = document.createTextNode("Felony");
	add10 = document.createElement("p");
	
	add15 = document.createTextNode("Desciption:");
	add16 = document.createElement("p");
	
	add11 = document.createElement("textarea");
	add11.setAttribute("rows","1");
	add11.setAttribute("cols","100");
	add11.setAttribute("id","crimedescription" +(Crime));
	add11.setAttribute("required", "");
	add12 = document.createElement("p");
	
	add13 = document.createTextNode("If you would like to add more please press the + symbol above or - symbol to remove");
	add14 = document.createElement("p");
	

	crim.append(add1,add2,add3,add4,add5,add7,add8,add9,add10,add15,add16,add11,add12,add13,add14);
	

	
}


function RemoveCrim(){
	if(Crime == 0){
	alert("Can not remove any further");
	}else{
	
		
		var a = document.getElementById("Crim");
	
		
		for(i=0; i<16;i++){
		a.removeChild(a.childNodes[a.childNodes.length -1]);
			
		}
		Crime--;
		
	}
	
}


Education = 0;

function addEducation(){
	
	ed = document.getElementById("Ed");
	
	

	add1 = document.createTextNode("School Name: ");
	
	add2 = document.createElement("input");
	add2.setAttribute("type","text");
	add2.setAttribute("id","SchoolName" +(++Education));
	add2.setAttribute("required", "");
	add3 = document.createElement("p");



	add4 = document.createTextNode("City/State: ");
	
	add5 = document.createElement("input");
	add5.setAttribute("type","text");
	add5.setAttribute("id","City/State" +(Education));
	add5.setAttribute("required", "");
	add6 = document.createElement("p");
	
	
	add7 = document.createTextNode("Graduation Date: ");
	
	add8 = document.createElement("input");
	add8.setAttribute("type","date");
	add8.setAttribute("id","GraduationDate" +(Education));
	add8.setAttribute("max","2025-12-31");
	add8.setAttribute("min","1955-01-01"); 
	add8.setAttribute("required", "");
	add9 = document.createElement("p");

	add10 = document.createTextNode("Major/Degree/Certificate: ");
	
	add11 = document.createElement("input");
	add11.setAttribute("type","text");
	add11.setAttribute("id","Major/Degree/Certificate" +(Education));
	add11.setAttribute("required", "");
	add12 = document.createElement("p");
	
	add13 = document.createTextNode("If you would like to add more please press the + symbol above or - symbol to remove");
	add14 = document.createElement("p");
	

	ed.append(add1,add2,add3,add4,add5,add6,add7,add8,add9,add10,add11,add12,add13,add14);
	
}
function RemoveEducation(){
	if(Education == 0){
	alert("Can not remove any further");
	}else{
		var a = document.getElementById("Ed");
	
		for(i=0; i<14;i++){
		a.removeChild(a.childNodes[a.childNodes.length -1]);
			
		}
		Education--;
		
	}
	
	
}
Work =0;

function addWork(){
	Wor = document.getElementById("Work_Section");
	

	add1 = document.createTextNode("Name of employer: ");
	
	add2 = document.createElement("input");
	add2.setAttribute("type","text");
	add2.setAttribute("id","Employer_Name" +(++Work));
	add2.setAttribute("required", "");
	add3 = document.createElement("p");



	add4 = document.createTextNode("Address of workplace: ");
	
	add5 = document.createElement("input");
	add5.setAttribute("type","text");
	add5.setAttribute("id","Address_WE" +(Work));
	add5.setAttribute("required", "");
	add6 = document.createElement("p");

	
	add7 = document.createTextNode("Name of supervisor: ");
	
	add8 = document.createElement("input");
	add8.setAttribute("type","text");
	add8.setAttribute("id","WE_Supervisor" +(Work));
	add8.setAttribute("required", "");
	add9 = document.createElement("p");

	
	
	add10 = document.createTextNode("Employment Dates: ");
	add31 = document.createElement("p");

	add11 = document.createTextNode("From: ");
	
	add12 = document.createElement("input");
	add12.setAttribute("type","date");
	add12.setAttribute("id","WE_From" +(Work));
	add12.setAttribute("required", "");
	add12.setAttribute("max","2025-12-31");
	add12.setAttribute("min","1955-01-01"); 
	add13 = document.createElement("p");
	

	add14 = document.createTextNode("To: ");
	
	add15 = document.createElement("input");
	add15.setAttribute("type","date");
	add15.setAttribute("max","2025-12-31");
	add15.setAttribute("min","1955-01-01"); 
	add15.setAttribute("id","WE_To" +(Work));
	add15.setAttribute("required", "");
	add16 = document.createElement("p");
	
	
	add17 = document.createTextNode("Employer phone number: ");
	add18 = document.createElement("input");
	add18.setAttribute("type","text");
	add18.setAttribute("id","WE_Phone" +(Work));
	add18.setAttribute("placeholder" ,"Ex: 123-456-7890");
	add18.setAttribute("required", "");
	add19 = document.createElement("p");
	
	
	
	add20 = document.createTextNode("Email: ");
	add21 = document.createElement("input");
	add21.setAttribute("type","text");
	add21.setAttribute("id","WE_Email" +(Work));
	add21.setAttribute("required", "");
	add22 = document.createElement("p");
	
	
	add23 = document.createTextNode("Job title: ");
	add24 = document.createElement("input");
	add24.setAttribute("type","text");
	add24.setAttribute("id","WE_Title" +(Work));
	add24.setAttribute("required", "");
	add25 = document.createElement("p");
	
	
	
	add26 = document.createTextNode("List your duties and any accomplishments you made: ");
	add27 = document.createElement("textarea");
	add27.setAttribute("rows","1");
	add27.setAttribute("cols","100");
	add27.setAttribute("id","WE_Accomplishments" +(Work));
	add27.setAttribute("required", "");
	add28 = document.createElement("p");
	
	
	add29 = document.createTextNode("If you would like to add more please press the + symbol above or - symbol to remove");
	add30 = document.createElement("p");	
	

	Wor.append(add1,add2,add3,add4,add5,add6,add7,add8,add9,add10,add31,add11,add12,add13,add14,add15,add16,add17,add18,
	add19,add20,add21,add22,add23,add24,add25,add26,add27,add28,add29,add30);
	
}


function RemoveWork(){
		if(Work == 0){
	alert("Can not remove any further");
	}else{
		var a = document.getElementById("Work_Section");
	
		for(i=0; i<31;i++){
		a.removeChild(a.childNodes[a.childNodes.length -1]);
			
		}
		Work--;
		
	}
}




Ref = 0;

function addRef(){
	
	re = document.getElementById("Ref");
	
	

	add1 = document.createTextNode("Name: ");
	
	add2 = document.createElement("input");
	add2.setAttribute("type","text");
	add2.setAttribute("id","RefName" +(++Ref));
	add2.setAttribute("required", "");
	add3 = document.createElement("p");



	add4 = document.createTextNode("Title: ");
	
	add5 = document.createElement("input");
	add5.setAttribute("type","text");
	add5.setAttribute("id","RefTitle" +(Ref));
	add5.setAttribute("required", "");
	add6 = document.createElement("p");
	
	
	add7 = document.createTextNode("Company: ");
	
	add8 = document.createElement("input");
	add8.setAttribute("type","text");
	add8.setAttribute("id","RefCompany" +(Ref));
	add8.setAttribute("required", "");
	add9 = document.createElement("p");

	add10 = document.createTextNode("Address: ");
	
	add11 = document.createElement("input");
	add11.setAttribute("type","text");
	add11.setAttribute("id","RefAddress" +(Ref));
	add11.setAttribute("required", "");
	add12 = document.createElement("p");
	
	
	add13 = document.createTextNode("Phone: ");
	add14 = document.createElement("input");
	add14.setAttribute("type","text");
	add14.setAttribute("id","RefPhone" +(Ref));
	add14.setAttribute("required", "");
	add14.setAttribute("placeholder" ,"Ex: 123-456-7890");
	add15 = document.createElement("p");
	
	add16 = document.createTextNode("Email: ");
	add17 = document.createElement("input");
	add17.setAttribute("type","text");
	add17.setAttribute("id","RefEmail" +(Ref));
	add17.setAttribute("required", "");
	add18 = document.createElement("p");
	
	
	
	add19 = document.createTextNode("If you would like to add more please press the + symbol above or - symbol to remove");
	add20 = document.createElement("p");
	

	re.append(add1,add2,add3,add4,add5,add6,add7,add8,add9,add10,add11,add12,add13,add14,add15,add16,add17,add18,add19,add20);
	
}
function RemoveRef(){
	if(Ref == 0){
	alert("Can not remove any further");
	}else{
	
		
		var a = document.getElementById("Ref");
	
		
		for(i=0; i<20;i++){
		a.removeChild(a.childNodes[a.childNodes.length -1]);
			
		}
		Ref--;
		
	}
}




function ForIdent(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Identification_tab");
		
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_Related_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Identification");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work_Related");
		nextactive.className = "";
		nextactive.className = nextactive.className.replace("", "active");
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}



function ForWR(){
	
	if(ValidateWR()){
		
		
		var current1 = document.getElementById("Work_Related_tab");
		current1.className = current1.className.replace("active tab", "tab");
			current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Criminal_BackGround_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work_Related");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Criminal_BackGround");
		nextactive.className = nextactive.className.replace("", "active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevWR(){
	
	if(ValidateWR()){
		
		
		var current1 = document.getElementById("Work_Related_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Identification_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work_Related");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Identification");
		nextactive.className = nextactive.className.replace("", "active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
}
	
function ForCrim(){
	
	if(ValidateCrim()){
		
		
		var current1 = document.getElementById("Criminal_BackGround_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Education_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Criminal_BackGround");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Education");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevCrim(){
	
	if(ValidateCrim()){
		
		
		var current1 = document.getElementById("Criminal_BackGround_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_Related_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Criminal_BackGround");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work_Related");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForEdu(){
	
	if(ValidateEdu()){
		
		
		var current1 = document.getElementById("Education_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Education");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}

}
function PrevEdu(){
	
	if(ValidateEdu()){
		
		
		var current1 = document.getElementById("Education_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Criminal_BackGround_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Education");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Criminal_BackGround");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForWork(){
	
	if(ValidateWork()){
		
		
		var current1 = document.getElementById("Work_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Refrences_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Refrences");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevWork(){
	
	if(ValidateWork()){
		
		
		var current1 = document.getElementById("Work_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Education_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Education");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForRef(){
	
	if(ValidateRef()){
		
		
		var current1 = document.getElementById("Refrences_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Waiver_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Refrences");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Waiver");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevRef(){
	
	if(ValidateRef()){
		
		
		var current1 = document.getElementById("Refrences_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Refrences");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevWaiver(){
	
	if(ValidateWaiver()){
		
		
		var current1 = document.getElementById("Waiver_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Refrences_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Waiver");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Refrences");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}


function testLength(value, length){
	if(value.length == length){
		return true;
	}else{
		return false;
	}
	
}


function validateEmail(value){
	
	var RegEx = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
	if (value.match(RegEx)){
    return true;
	}else{
	
    return false;
	}
}

function validatePhone(value){
	
	var RegEx = /([0-9]{3}\-[0-9]{3}\-[0-9]{4})/;
	if (value.match(RegEx)){
    return true;
	}else{
	
    return false;
	}
}


function validateDate(value){
	var today= new Date();
	var value = value.split("-");
	
	if(value[0] > today.getFullYear()){
		return true;
	}else if(value[0] == today.getFullYear() && value[1] > today.getMonth() + 1  ){
			return true;
	}else if(value[0] == today.getFullYear() && value[1] == today.getMonth() + 1 && value[2] > today.getDate()){
			return true;
	}
	else{
		
		return false;
	}
	
}
function validatetoday(value){
	var today= new Date();
	var value = value.split("-");
	
	if(value[0] == today.getFullYear() && value[1] == today.getMonth() + 1 && value[2] == today.getDate()){
			return true;
	}
	else{
		return false;
	}
	
}
function BeforeAndtoday(value){
	var today= new Date();
	var value = value.split("-");
	
	if(value[0] < today.getFullYear()){
		return true;
	}else if(value[0] == today.getFullYear() && value[1] < today.getMonth() + 1  ){
			return true;
	}else if(value[0] == today.getFullYear() && value[1] == today.getMonth() + 1 && value[2] < today.getDate()){
			return true;
	}
	else{
		return false;
	}
	
}
function comparedate(valuefrom , valueto){
	var value1 = valuefrom.split("-");
	var value2 = valueto.split("-");
	
	if(value1[0] < value2[0]){
		return true;
	}else if(value1[0] == value2[0] && value1[1] < value2[1]  ){
			return true;
	}else if(value1[0] == value2[0] && value1[1] == value2[1] && value1[2] < value2[2]){
			return true;
	}
	else{
		return false;
	}
	
}



function testNumber(value){
	
	if(!isNaN(value)){
		return true;
	}else{
	return false;	
	}
}

function validateState(value){
	if(!value.match("selectState")){
		return true;
	}else{
		return false;
	}
	
}


function ValidateIndent(){

	
	
	if(document.getElementById("applicantname").value.length == 0){
		alert("Please enter a name in the identification tab");
		return false;
	}
	
	if((!validateEmail(document.getElementById("applicantemail").value))){
		  alert("Invalid email address input in the identification tab");
		   return false;
	}
	
	if(!validatetoday(document.getElementById("appdate").value)){
		alert("Please select today date for the application in the identification tab");
		return false;
	}
	if(document.getElementById("applicantaddress").value.length == 0){
		alert("Please enter your address in the identification tab");
		return false;
	}
	if(document.getElementById("city").value.length == 0){
		alert("Please enter your city in the identification tab");
		return false;
	}
	if(!validateState(document.getElementById("state").value)){
		alert("Please select your state in the identification tab");
		return false;
	}
	if( (document.getElementById("Zip").value.length == 5 ) && testNumber(document.getElementById("Zip").value)){
	}else{
			alert("Your Zip Code appears to be incorrect in the identification tab");
		return false;
	}	
	if(document.getElementById("SSN").value.length == 0){
		alert("Please enter your Social Security Number in the identification tab");
		return false;
	}
	if(document.getElementById("ageconfirm").checked || document.getElementById("agedeny").checked){
	}else{
	alert("Please answer if you are at least 18 in the identification Work tab");
	return false;
	}
	if(document.getElementById("DLconfirm").checked || document.getElementById("DLDeny").checked){
	}else{
	alert("Please answer if you have a valid driver license in the identification Work tab");
	return false;
	}
	
	if(document.getElementById("DLconfirm").checked){
		if(document.getElementById("license").value.length == 0 ){
		alert("Please enter a valid driver license number identification Work tab");
		return false;
		}
		if(!validateDate(document.getElementById("licenseexp").value)){
		alert("Please enter a valid driver license date in the identification Work tab");
		return false;
		}
	
		
	}

	if(validatePhone(document.getElementById("phone").value)){}
	else{
	alert("Please enter a valid phone number in the identification Work tab");
	return false;
	}
	
	if(document.getElementById("yesdrive").checked || document.getElementById("nodrive").checked){
	}else{
	alert("Please answer if you are willing to drive your personal vehicle in the identification Work tab");
	return false;
	}
	if(document.getElementById("yesdrive").checked){
		if(document.getElementById("vehiclemake").value.length == 0){
		alert("Please answer the vehicle make in the identification Work tab");
		return false;
		}
		if(document.getElementById("vehiclemodel").value.length == 0){
		alert("Please answer vehicle model in the identification Work tab");
		return false;
		}
		if(document.getElementById("vehicleyear").value.length != 4 || !testNumber(document.getElementById("vehicleyear").value)){
		alert("Please answer a valid vehicle year in the identification Work tab");
		return false;
		}
		
	}
	
	if(document.getElementById("militaryconfirm").checked || document.getElementById("militarydeny").checked){
	}else{
	alert("Please answer if you have ever served in the military in the identification Work tab");
	return false;
	}
	if(document.getElementById("militaryconfirm").checked){
		if(document.getElementById("airforce").checked ||document.getElementById("coastguard").checked ||document.getElementById("nationalguard").checked ||
			document.getElementById("army").checked || document.getElementById("marines").checked ||document.getElementById("navy").checked){
		}else{
		alert("Please select the military branch you served in the identification Work tab");
		return false;
		}
	
		
	}
	
	
	return true;
	
}



function ValidateWR(){
	if(document.getElementById("applicantposition").value.length == 0){
		alert("Please enter your applied position in the Desired Work tab");
		return false;
	}
	if(document.getElementById("applicantsalary").value.length == 0 ){
		alert("Please enter your Desired salary in the Desired Work tab");
		return false;
	}else if(!testNumber(document.getElementById("applicantsalary").value)){
		alert("Please enter only numbers in the Desired salary field in the Desired Work tab");
		return false;
	}
	if(document.getElementById("Monday").checked ||document.getElementById("Tuesday").checked ||document.getElementById("Wednesday").checked ||
	document.getElementById("Thursday").checked ||document.getElementById("Friday").checked ||document.getElementById("Saturday").checked ||
	document.getElementById("Sunday").checked){}
	else{
	alert("Please enter at least one day available to work in the Desired Work tab");
	return false;}
	if(document.getElementById("nightsconfirm").checked || document.getElementById("nightsdeny").checked){
	}else{
	alert("Please choose if you can work nights in the Desired Work tab");
	return false;
	}
	if(document.getElementById("parttime").checked || document.getElementById("fulltime").checked){
	}else{
	alert("Please choose to applied for Part-time, Full-time, or both in the Desired Work tab");
	return false;
	}
	if(!validateDate(document.getElementById("startdate").value)){
		alert("Please select a day after today that is the soonest you will be able to work in the Desired Work tab");
		return false;
	}
	
	return true;
}
function ValidateCrim(){
	
	if(Crime > 0){
		for( i = 1 ; i<= Crime; i++){
			if( !BeforeAndtoday(document.getElementById("DateCrime" +i).value) || document.getElementById("DateCrime" +i).value == ""){
				alert("invalid date for Crime Date in entry " + i +" in the Criminal BackGround tab");
				return false;
			}
		if(document.getElementById("misdemeanor" + i).checked ||document.getElementById("felony" +i).checked){
		}else {
			alert("please select whether it is a misdemeanor or felony crime in entry " + i +" in the Criminal BackGround tab");
				return false;
			}
		if(document.getElementById("crimedescription" + i).value.length == 0){
				alert("Please enter the crime desciption in entry " + i +" in the Criminal BackGround tab");
				return false;
			}
		}
		
		
	}
	
	return true;
}
function ValidateEdu(){
	if(document.getElementById("edulevel").value.length == 0){
		alert("Please enter your highest diploma/degree/certificate you have earned in the Education tab or N/A if you choose not to answer");
		return false;
	}
	
	
	if(Education > 0){
		for( i = 1 ; i<= Education; i++){
			if(document.getElementById("SchoolName" + i).value.length == 0){
				alert("Please enter School Name in entry " + i +" in the Education tab");
				return false;
			}
			if(document.getElementById("City/State" + i).value.length == 0){
				alert("Please enter School City/State in entry " + i +" in the Education tab");
				return false;
			}
			if( !BeforeAndtoday(document.getElementById("GraduationDate"+ i).value) || document.getElementById("GraduationDate" +i).value == ""){
					alert("invalid date for Graduation Date in entry " + i +" in the Education tab");
				return false;
			}
			
			
			if(document.getElementById("Major/Degree/Certificate" + i).value.length == 0){
				alert("Please enter the Major/Degree/Certificate you have earned in entry " + i +" in the Education tab");
				return false;
			}
		
	}
		
		
	}
	
	
	
	return true;
}
function ValidateWork(){
	
	if(Work > 0){
		for( i = 1 ; i<= Work; i++){
			if(document.getElementById("Employer_Name" + i).value.length == 0){
				alert("Please enter Employer Name in entry " + i +" in the Work Experience tab");
				return false;
			}
			if(document.getElementById("Address_WE" + i).value.length == 0){
				alert("Please enter the address of the workplace in entry " + i +" in the Work Experience tab");
				return false;
			}
			if(document.getElementById("WE_Supervisor" + i).value.length == 0){
				alert("Please enter the supervisor in entry " + i +" in the Work Experience tab or enter N/A if you choose not to answer");
				return false;
			}
		
			if( !BeforeAndtoday(document.getElementById("WE_From"+ i).value) || document.getElementById("WE_From" +i).value == ""){
					alert("invalid date for the beginning or from employment date in entry " + i +" in the Work Experience tab");
				return false;
			}
		
			if( (!comparedate(document.getElementById("WE_From"+ i).value , document.getElementById("WE_To" +i).value)) || document.getElementById("WE_To" +i).value == ""){
					alert("invalid date for the end or to employment date in entry " + i +" in the Work Experience tab");
				return false;
			}
		
			if(validatePhone(document.getElementById("WE_Phone" + i).value)){}
				else{
					alert("Please enter a valid Employer Phone Number in entry " + i +" in the Work Experience or enter N/A if you choose not to answer");
			
				return false;
				}
				
			if((!validateEmail(document.getElementById("WE_Email" + i).value))){
			alert("Invalid email address in entry " + i +" in the Work Experience");
			return false;
			}
				
			if(document.getElementById("WE_Title" + i).value.length == 0){
				alert("Please enter the job title in entry " + i +" in the Work Experience tab");
				return false;
			}
			if(document.getElementById("WE_Accomplishments" + i).value.length == 0){
				alert("Please enter your duties or accomplishments in entry " + i +" in the Work Experience tab");
				return false;
			}
		
		
	}
		
		
	}
	
	return true;
}
function ValidateRef(){
	
		if(Ref > 0){
		for( i = 1 ; i<= Ref; i++){
			if(document.getElementById("RefName" + i).value.length == 0){
				alert("Please enter the References Name or N/A in entry " + i +" in the References tab");
				return false;
			}
			if(document.getElementById("RefTitle" + i).value.length == 0){
				alert("Please enter the References job Title in entry " + i +" in the References tab");
				return false;
			}
			
			
			
			if(document.getElementById("RefCompany" + i).value.length == 0){
				alert("Please enter the References Company in entry " + i +" in the References tab");
				return false;
			}
			if(document.getElementById("RefAddress" + i).value.length == 0){
				alert("Please enter the References Address in entry  " + i +" in the References tab or enter N/A if you choose not to answer");
				return false;
			}
		
			if(validatePhone(document.getElementById("RefPhone" + i).value)){}
				else{
					alert("Please enter a valid References Phone Number in entry " + i +" in the References tab or enter N/A if you choose not to answer");
			
				return false;
				}
			
			if((!validateEmail(document.getElementById("RefEmail" + i).value))){
			alert("Invalid email address in entry " + i +" in the References tab or enter N/A if you choose not to answer");
			return false;
				}
				
			
		
		}
		
		
	}
	
	
	return true;
}
function ValidateWaiver(){
	if(!document.getElementById("WaiverConfirmation").checked){
		alert("You have to agree to the waiver in the waiver/submit tab for this application to be reviewed");
		return false;
	}
	
	
	return true;
}





function Check(){
	if(ValidateIndent() && ValidateWR() && ValidateCrim() && ValidateEdu() && ValidateWork() &&ValidateRef() &&ValidateWaiver()){
		alert("Congratulations You Have Completed Your Application! It Is Now In The Process of Getting Review.");
	return true;
	}else{

		return false;
	}
	
	
}
