


const tabs = document.querySelectorAll('[data-tab-target]');
const tabContents = document.querySelectorAll('[data-tab-content]');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const target = document.querySelector(tab.dataset.tabTarget);
    tabContents.forEach(tabContent => {
      tabContent.classList.remove('active');
    })
    tabs.forEach(tab => {
      tab.classList.remove('active');
    })
    tab.classList.add('active');
    target.classList.add('active');
  })
})

function CriminalY(){
		document.getElementById('test').style.display = "block";
	
}
function CriminalN(){
		document.getElementById('test').style.display = "none";
	
}

function MilitaryY(){
		document.getElementById('military').style.display = "block";
		
		document.getElementById('airforce').required = true;
}
function MilitaryN(){
		document.getElementById('military').style.display = "none";
		
		document.getElementById('airforce').required = false;
	
}

function vehicleY(){
		document.getElementById('vehicle').style.display = "block";
	
}
function vehicleN(){
		document.getElementById('vehicle').style.display = "none";
	
}

Education = 0;

function addEducation(){
	
	ed = document.getElementById("Ed");
	
	

	add1 = document.createTextNode("School Name: ");
	
	add2 = document.createElement("input");
	add2.setAttribute("type","text");
	add2.setAttribute("id","SchoolName" +(++Education));
	add2.setAttribute("required", "");
	add3 = document.createElement("p");



	add4 = document.createTextNode("City/State: ");
	
	add5 = document.createElement("input");
	add5.setAttribute("type","text");
	add5.setAttribute("id","City/State" +(Education));
	add5.setAttribute("required", "");
	add6 = document.createElement("p");
	
	
	add7 = document.createTextNode("Graduation Date: ");
	
	add8 = document.createElement("input");
	add8.setAttribute("type","date");
	add8.setAttribute("id","GraduationDate" +(Education));
	add8.setAttribute("required", "");
	add9 = document.createElement("p");

	add10 = document.createTextNode("Major/Degree/Certificate: ");
	
	add11 = document.createElement("input");
	add11.setAttribute("type","text");
	add11.setAttribute("id","Major/Degree/Certificate" +(Education));
	add11.setAttribute("required", "");
	add12 = document.createElement("p");
	
	add13 = document.createTextNode("If you would like more please press the + sign above");
	add14 = document.createElement("p");
	

	ed.append(add1,add2,add3,add4,add5,add6,add7,add8,add9,add10,add11,add12,add13,add14);
	
}

Ref = 0;

function addRef(){
	
	re = document.getElementById("Ref");
	
	

	add1 = document.createTextNode("Name: ");
	
	add2 = document.createElement("input");
	add2.setAttribute("type","text");
	add2.setAttribute("id","Name" +(++Ref));
	add2.setAttribute("required", "");
	add3 = document.createElement("p");



	add4 = document.createTextNode("Title: ");
	
	add5 = document.createElement("input");
	add5.setAttribute("type","text");
	add5.setAttribute("id","Title" +(Ref));
	add5.setAttribute("required", "");
	add6 = document.createElement("p");
	
	
	add7 = document.createTextNode("Company: ");
	
	add8 = document.createElement("input");
	add8.setAttribute("type","text");
	add8.setAttribute("id","Company" +(Ref));
	add8.setAttribute("required", "");
	add9 = document.createElement("p");

	add10 = document.createTextNode("Address: ");
	
	add11 = document.createElement("input");
	add11.setAttribute("type","text");
	add11.setAttribute("id","Address" +(Ref));
	add11.setAttribute("required", "");
	add12 = document.createElement("p");
	
	
	add13 = document.createTextNode("Phone: ");
	add14 = document.createElement("input");
	add14.setAttribute("type","text");
	add14.setAttribute("id","Phone" +(Ref));
	add14.setAttribute("required", "");
	add15 = document.createElement("p");
	
	add16 = document.createTextNode("Email: ");
	add17 = document.createElement("input");
	add17.setAttribute("type","text");
	add17.setAttribute("id","Email" +(Ref));
	add17.setAttribute("required", "");
	add18 = document.createElement("p");
	
	
	
	add19 = document.createTextNode("If you would like more please press the + sign above");
	add20 = document.createElement("p");
	

	re.append(add1,add2,add3,add4,add5,add6,add7,add8,add9,add10,add11,add12,add13,add14,add15,add16,add17,add18,add19,add20);
	
}
function RemoveRef(){
	if(Ref == 0){
	alert("Can not remove and further");
	}else{
		var a = document.getElementById("Name"+Ref);
		a.remove();
	}
}




function ForIdent(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Identification_tab");
		
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_Related_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Identification");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work_Related");
		nextactive.className = nextactive.className.replace("", "active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForWR(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Work_Related_tab");
		current1.className = current1.className.replace("active tab", "tab");
			current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Criminal_BackGround_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work_Related");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Criminal_BackGround");
		nextactive.className = nextactive.className.replace("", "active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevWR(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Work_Related_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Identification_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work_Related");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Identification");
		nextactive.className = nextactive.className.replace("", "active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
}
	
function ForCrim(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Criminal_BackGround_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Education_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Criminal_BackGround");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Education");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevCrim(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Criminal_BackGround_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_Related_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Criminal_BackGround");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work_Related");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForEdu(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Education_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Education");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}

}
function PrevEdu(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Education_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Criminal_BackGround_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Education");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Criminal_BackGround");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForWork(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Work_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Refrences_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Refrences");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevWork(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Work_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Education_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Work");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Education");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function ForRef(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Refrences_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Waiver_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Refrences");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Waiver");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevRef(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Refrences_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Work_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Refrences");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Work");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}
function PrevWaiver(){
	
	if(ValidateIndent()){
		
		
		var current1 = document.getElementById("Waiver_tab");
		current1.className = current1.className.replace("active tab", "tab");
		current1.className = current1.className.replace("tab active", "tab");
		
		var nextactive1 = document.getElementById("Refrences_tab");
		nextactive1.className = nextactive1.className.replace("tab", "active tab");
		
		
		
		var current = document.getElementById("Waiver");
		current.className = current.className.replace("active", "");
		
		var nextactive = document.getElementById("Refrences");
		nextactive.className = nextactive.className.replace("", " active");
	
	
	
		
		return true;
	}else{
		return false;
		
	}
	
}


function ValidateIndent(){
	
	return true;
}


function Check(){
	alert("Congratulations You Have Completed Your Application! It Is Now In The Process of Getting Review.");
	return true;
}
